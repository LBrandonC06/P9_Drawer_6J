package com.example.p9drawer6j

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
